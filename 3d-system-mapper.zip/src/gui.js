// GUI controls placeholder
